<br>
<footer class="text-center text-lg-start bg-light text-muted ">
    <!-- Copyright -->
    <div class="text-center p-4">
        <a class="text-reset fw-bold" href="home/indexProduto.php" target="blank">Teste</a>
    </div>
</footer>