<?php

    #Leva a pagina de login
    header("location: ./app/controller/loginController.php?action=login");

