<?php
#Nome do arquivo: tipoUsuario.php
#Objetivo: classe Enum para os papeis de permissões do model de Usuario

class TipoUsuario {

    const CLIENTE = "C";
    const VENDEDOR = "V";
    const ADMINISTRADOR = "A";

}

