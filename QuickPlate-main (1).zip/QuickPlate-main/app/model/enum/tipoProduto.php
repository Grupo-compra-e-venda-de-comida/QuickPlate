<?php
#Nome do arquivo: tipoProduto.php
#Objetivo: classe Enum para as categorias dos produtos

class TipoProduto {

    const SALGADO = "S";
    const DOCE = "D";
    const BEBIDA = "B";

}