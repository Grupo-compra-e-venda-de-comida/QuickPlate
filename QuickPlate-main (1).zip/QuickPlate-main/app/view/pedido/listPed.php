<?php
require_once(__DIR__ . "/../include/header.php");
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js" integrity="sha384-Rx+T1VzGupg4BHQYs2gCW9It+akI2MM/mndMCy36UVfodzcJcF0GGLxZIzObiEfa" crossorigin="anonymous"></script>
<link href="../css/sticky-footer.css" rel="stylesheet">

<div class="container-fluid pb-5" style="margin-top: 270px; margin-bottom: 75px;">

    <!-- Navbar -->
    <div class="row">
        <?php
        require_once(__DIR__ . "/../include/menu.php");
        ?>
    </div>

    <!-- Texto -->
    <div class="row">
        <div class="col-12">
            <div style="margin: auto; text-align: center;" class="m-2">
                <h2>PEDIDOS</h2>
            </div>

            <?php //print_r($dados['listPed']); ?>

            <div class="row row-cols-1 row-cols-md-3 g-4">
                <?php foreach ($dados['listPed'] as $ped) : ?>
                    <div class="col">
                        <div class="card text-center h-100 w-100 mr-2">
                            <div class="card-header">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#name<?= $ped->getIdPedido() ?>" role="tab" data-toggle="tab">Nome</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#itens<?= $ped->getIdPedido() ?>" role="tab" data-toggle="tab">Itens</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#status<?= $ped->getIdPedido() ?>" role="tab" data-toggle="tab">Status</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="card-body">
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane active" id="name<?= $ped->getIdPedido() ?>">
                                        <h5> <?= print_r($ped->getNomeCliente()) ?> </h5><br>
                                    </div>

                                    <div role="tabpanel" class="tab-pane" id="itens<?= $ped->getIdPedido() ?>">
                                        <?php print_r($ped->getItensPedido()) ?>
                                    </div>

                                    <div role="tabpanel" class="tab-pane" id="status<?= $ped->getIdPedido() ?>">
                                        <?php print_r($ped->getItensPedido()) ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div> <!-- /row -->

    <div class="row">
        <div class="col-6">
            <a class="btn btn-success mt-3" href="homeController.php?action=homeVendedor">Voltar</a>
        </div>
    </div>

    <!--Footer-->
    <?php
    require_once(__DIR__ . "/../include/footer.php");
    ?>

</div>